def extract_last_and_first(string):
    return f"Primera letra: {string[0]}, Última letra: {string[-1]}"
  
def main():
    print(extract_last_and_first("Hola Mundo"))
    
main()