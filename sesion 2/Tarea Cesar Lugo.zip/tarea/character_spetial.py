def character_special():
  return "¡Hola, mundo! ¿Cómo estás? #FelizDía"
  
def main():
  print(character_special())
  
main()