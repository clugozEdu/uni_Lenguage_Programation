def concat_numer (number_1, number_2):
  return str(number_1) + str(number_2)
    
def main():
  print(concat_numer(100, 101))

main()