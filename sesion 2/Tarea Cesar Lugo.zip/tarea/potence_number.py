def potence_number(num):
  return f"Cuadrado: {num ** 2}, Cubo: {num ** 3}, Cuarta: {num ** 4}"

def main():
  print(potence_number(112))
  
main()