def pow_number(num):
  return f"Cuadrado: {num ** 2}, Cubo: {num ** 3}, Cuarta: {num ** 4}"


def main():
  print(pow_number(112))
  
main()