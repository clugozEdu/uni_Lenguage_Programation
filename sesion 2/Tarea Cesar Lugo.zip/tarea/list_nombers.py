def list_nombers(list):
  return f"El el tercer elemento de la lista es: {list[2]}"

def main():
  print(list_nombers(["Hola", "Mundo", "Cruel", "Adios", "Mundo"]))
  
main()
