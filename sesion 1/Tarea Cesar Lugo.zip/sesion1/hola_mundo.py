# Hola mundo en Python
print("Hola Mundo")